// ===================================================================
//  CONFIGURACAO DA CONGREGACAO
//  Troque cada COLE_AQUI pelos dados do SEU projeto no Firebase.
//  (Firebase > Configuracoes do projeto > Seus apps > App da Web > firebaseConfig)
// ===================================================================
window.CONFIG_FIREBASE = {
  apiKey: "COLE_AQUI",
  authDomain: "COLE_AQUI",
  databaseURL: "COLE_AQUI",
  projectId: "COLE_AQUI",
  storageBucket: "COLE_AQUI",
  messagingSenderId: "COLE_AQUI",
  appId: "COLE_AQUI"
};

// UID da conta do RESPONSAVEL (o unico que pode apagar e alterar dados).
// Firebase > Authentication > Usuarios > copie o "UID do usuario".
// As outras contas autorizadas entram como ajudantes.
window.CONFIG_DONO_UID = "COLE_AQUI_O_UID_DO_RESPONSAVEL";
